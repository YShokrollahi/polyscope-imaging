<?php

// Server credentials

$externalLink = "http://polyzoomer.icr.ac.uk/";

?>
