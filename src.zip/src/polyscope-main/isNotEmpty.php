<?php
/*
	Desc: Test if a variable is empty.
	Author:	Sebastian Schmittner
	Date: - 
	Last Author: Sebastian Schmittner
	Last Date: 2014.07.19
	Version: 0.0.1
*/

function isNotEmpty($var)
{
  return ($var != '');
}

?>

