#!/bin/bash

# Author: Sebastian Schmittner
# Date: 2015.05.18
# LastAuthor: Sebastian Schmittner
# LastDate: 2015.05.18
# Version: 0.0.0

echo "Setting up mounts"

mkdir ~/polyzoomer/analyses
mkdir ~/polyzoomer/analyses/analysis_in
mkdir ~/polyzoomer/analyses/analysis_out

echo "Done"

