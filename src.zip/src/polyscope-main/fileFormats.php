<?php
/*
	Desc: Extension which will be allowed to be processed.
	Author:	Sebastian Schmittner
	Date: - 
	Last Author: Sebastian Schmittner
	Last Date: -
	Version: 0.0.1
*/

$pz_fileFormats = array(
	"svs",
	"ndpi",
	"tif",
	"jpg",
	"jpeg",
	"tiff",
	"png",
    "czi",
);

?>